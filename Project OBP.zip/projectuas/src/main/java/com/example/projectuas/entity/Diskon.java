package com.example.projectuas.entity;

public interface Diskon {
    double hitungDiskon();
}